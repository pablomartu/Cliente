/*
Vas a crear un pequeño test sobre la serie de televisión que tú quieras. 
El test tendrá 10 preguntas con 3 respuestas cada una a elegir con botones de radio. 
El test deberá hacer lo siguiente: 
• Cuando el usuario conteste las 10 preguntas obtendrá el resultado final en un cuadro de texto. 
• Además, el usuario podrá ver qué preguntas ha fallado, porque al enviar el formulario
  le aparecerá un pequeño icono con un tic verde en las preguntas correctas y una cruz roja en las preguntas incorrectas. 
• En caso de que el usuario deje alguna pregunta sin contestar, no mostrará el resultado 
  e indicará con un mensaje "No has respondido a todas las preguntas". Y se marcará en 
  color rojo la pregunta que no haya sido respondida.
*/

//Preguntas del test
let preguntas = document.getElementsByTagName("h4");
//Respuestas correctas para comparar con la seleccionada
let respuestas = ["mouseover", "funcion", "w3c", "load", "target", "novalidate", "null", "x427x9", "docCookie", "sessionStorage"];
//Array booleano para comprobar que se han contestado las preguntas
let seleccionadas = [];
//Contador de aciertos
let correctas = 0;
//Array booleano para almacenar si han respondido bien o mal
let resultado = [];

document.addEventListener("DOMContentLoaded", () => {
    document.getElementById("enviar").addEventListener("click", comprobar);
});

//Función para comprobar si han respondido a todas preguntas,
// si hay respuesta, se comprueba si es correcta o no
function comprobar() {
    //Recorremos las preguntas
    for (let i = 0; i < preguntas.length; i++) {
        //En principio no hay respuesta seleccionada
        seleccionadas[i] = false;
        let opciones = document.getElementsByName((i + 1).toString());
        for (let j = 0; j < opciones.length; j++) { //Cada respuesta de una pregunta
            if (opciones[j].checked) { //Si esta seleccionada
                seleccionadas[i] = true;
                if (opciones[j].value === respuestas[i]) { //Si es la respuesta es correcta
                    resultado[i] = true;
                    correctas++;
                } else {
                    resultado[i] = false;
                }
            }
        }
        //Si no se ha marcado una respuesta se resalta la pregunta en rojo
        if (!seleccionadas[i]) {
            preguntas[i].style.color = "red"; //Cambiar el color de la pregunta
        } else {
            preguntas[i].style.color = "black"; //Cambiar el color de la pregunta
        }
    }
    mostrarResultado();
}

//Función para mostrar el resultado obtenido
function mostrarResultado() {
    document.getElementById("mensaje").style.display = "block";
    if (!seleccionadas.includes(false)) {  //Si se han contestado todas
        for (let i = 0; i < resultado.length; i++) { //Marcamos correctas e incorrectas
            if (resultado[i]) {
                preguntas[i].nextElementSibling.style.display = "block";
                preguntas[i].nextElementSibling.nextElementSibling.style.display = "none";
            } else {
                preguntas[i].nextElementSibling.style.display = "none";
                preguntas[i].nextElementSibling.nextElementSibling.style.display = "block";
            }
        }
        document.getElementById("mensaje").innerHTML = "Has acertado " + correctas + "/10";
        //Limpiamos el número de aciertos
        correctas = 0;
    } else { //Si no se han contestado todas
        document.getElementById("mensaje").innerHTML = "No has respondido a todas las preguntas";
    }
}
let formulario;
//Si localStorage ya tenía un valor, lo usamos, en otro caso lo inicializamos a 0
let intentos = localStorage.getItem("intentos") || 0;

document.addEventListener("DOMContentLoaded", ()=> {
    formulario = document.forms[0];
    document.getElementById("enviar").addEventListener("click", validar);

    //Damos valor al campo intentos   
    document.getElementById("intentos").value = intentos;
    //Botón para reiniciar los intentos
    document.getElementById("rmintentos").addEventListener("click", reiniciarIntentos);
});

function validaFechaCreacion() {
    let elemento = document.getElementById("fechaCreacion");
    if (!elemento.validity.valid) {
        if (elemento.validity.valueMissing) {
            error(elemento, "Debe introducir una fecha")
        } else if (elemento.validity.patternMismatch) {
            error(elemento, "El formato de la fecha debería ser dd/mm/aaaa");
        } else { // No se va a dar este caso porque no hay más condiciones
            error(elemento, elemento.validationMessage);
        }
        return false;
    }
    /* Validamos la fecha */
    let dCreac = parseInt(elemento.value.substr(0, 2));
    let mCreac = parseInt(elemento.value.substr(3, 2));
    let aCreac = parseInt(elemento.value.substr(6, 4));

    let fCreac = new Date(aCreac, mCreac - 1, dCreac);
    if (fCreac.getFullYear() !== aCreac || fCreac.getMonth() + 1 !== mCreac || fCreac.getDate() !== dCreac) {
        error(elemento, "Has introducido una fecha no válida");
        return false;
    }
    return true;
}

function validaCocinero() {
    let elemento = document.getElementById("cocinero");
    if (!elemento.validity.valid) {
        if (elemento.validity.patternMismatch) {
            error(elemento, "El código del cocinero debería ser: dos mayúsculas, un símbolo y cuatro dígitos (ej. WW$1234)");
        } else { // No se va a dar este caso porque no hay más condiciones
            error(elemento, elemento.validationMessage);
        }
        return false;
    }
    return true;
}

function validaDestinatario() {
    let elemento = document.getElementById("destinatario");
    if (!elemento.validity.valid) {
        if (elemento.validity.patternMismatch) {
            error(elemento, "El código del destinatario debería ser: dos o tres mayúsculas, un guión bajo, el nombre de la ciudad en minúsculas, dos puntos y el código de distrito de cuatro dígitos (ej. MM_alburquerque:1234)");
        } else { // No se va a dar este caso porque no hay más condiciones
            error(elemento, elemento.validationMessage);
        }
        return false;
    }
    return true;
}

function validaGramos() {
    let elemento = document.getElementById("gramos");
    if (!elemento.validity.valid) {
        if (elemento.validity.patternMismatch) {
            error(elemento, "Introduzca un número entre 100 y 500");
        } else if (elemento.validity.rangeOverflow) {
            error(elemento, "Introduzca un número entre 100 y 500");
        } else if (elemento.validity.rangeUnderflow) {
            error(elemento, "Introduzca un número entre 100 y 500");
        } else { // No se va a dar este caso porque no hay más condiciones
            error(elemento, elemento.validationMessage);
        }
        return false;
    }
    return true;
}

function validaComposicion() {
    let elemento = document.getElementById("composicion");
    if (!elemento.validity.valid) {
        if (elemento.validity.patternMismatch) {
            error(elemento, "Introduzca una cantidad de gramos, seguida de dos conjuntos de una o dos letras seguidas o no de un número (ej. 200gC2OH7)");
        } else { // No se va a dar este caso porque no hay más condiciones
            error(elemento, elemento.validationMessage);
        }
        return false;
    }
    return true;
}

function validaCuenta() {
    let elemento = document.getElementById("cuenta");
    if (!elemento.validity.valid) {
        if (elemento.validity.patternMismatch) {
            error(elemento, "El número de cuenta no corresponde con el formato de las cuentas de EEUU");
        } else {
            error(elemento, elemento.validationMessage);
        }
        return false;
    }
    /* Otras validaciones */
    let cuenta = elemento.value.toUpperCase();
    if (cuenta !== "") {
        let letras = cuenta.substring(0, 2);
        let digitosControlLetras = parseInt(cuenta.substring(2, 4));
        let digitosCuenta = cuenta.substring(5, 17);
        let digitoControlNumeros1 = parseInt(cuenta.substring(18, 19));
        let digitoControlNumeros2 = parseInt(cuenta.substring(19, 20));

        // Validar que los dígitos de control de las letras son correctos: debe corresponderse
        // con la suma de la primera letra y la segunda: en caso de que sea menor que 10 se pone el 0 delante.
        let vocabulario = "-ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        let sumaLetras = vocabulario.indexOf(letras[0]) + vocabulario.indexOf(letras[1]);
        if (sumaLetras !== digitosControlLetras) {
            error(elemento, "Los dígitos de control de las letras deberían ser " + sumaLetras);
            return false;
        }
        // Validar que los dígitos de control de los números son correctos: 
        // - el primero debe ser la suma de los 6 primeros dígitos de 
        //   la cuenta dividido entre 6 y extrayendo solamente su parte entera;
        // - el segundo exactamente igual, pero con los 6 siguientes.
        let sumaParte1 = parseInt(digitosCuenta.charAt(0)) +
            parseInt(digitosCuenta.charAt(1)) +
            parseInt(digitosCuenta.charAt(2)) +
            parseInt(digitosCuenta.charAt(3)) +
            parseInt(digitosCuenta.charAt(4)) +
            parseInt(digitosCuenta.charAt(5));
        if (Math.floor(sumaParte1 / 6) !== digitoControlNumeros1) {
            error(elemento, "El primer dígito de control del número debería ser " + Math.floor(sumaParte1 / 6));
            return false;
        }
        let sumaParte2 = parseInt(digitosCuenta.charAt(6)) +
            parseInt(digitosCuenta.charAt(7)) +
            parseInt(digitosCuenta.charAt(8)) +
            parseInt(digitosCuenta.charAt(9)) +
            parseInt(digitosCuenta.charAt(10)) +
            parseInt(digitosCuenta.charAt(11));
        if (Math.floor(sumaParte2 / 6) !== digitoControlNumeros2) {
            error(elemento, "El segundo dígito de control del número debería ser " + Math.floor(sumaParte2 / 6));
            return false;
        }

        document.getElementById("cuentaSinGuiones").innerHTML =
            elemento.value.replace(/-/g, "");
    }
    return true;
}

function validar(e) {
    borrarError();
    if (validaFechaCreacion() && validaCocinero() &&
        validaDestinatario() && validaGramos() &&
        validaComposicion() &&
        validaCuenta() &&
        confirm("Pulsa aceptar si deseas enviar el formulario")) {
        reiniciarIntentos();
        return true;
    } else {
        e.preventDefault();
        return false;
    }
}

function error(elemento, mensaje) {
    document.getElementById("mensajeError").innerHTML = mensaje;
    elemento.className = "error";
    elemento.focus();
    //Incrementamos los intentos
    actualizarIntentos(1);
}

function borrarError() {
    for (let i = 0; i < formulario.elements.length; i++) {
        formulario.elements[i].className = "";
    }
    document.getElementById("mensajeError").innerHTML = "";
}

/*** Funciones para el trabajo con localStorage ***/
const reiniciarIntentos = () => {
    actualizarIntentos(0);
}

const actualizarIntentos = (valor) => {
    if (valor === 0) intentos = 0
    else intentos++;
    localStorage.setItem("intentos", intentos);
    document.getElementById("intentos").value = intentos;
}
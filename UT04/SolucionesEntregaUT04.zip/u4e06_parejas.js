/*
Vas a crear un juego de memorizar parejas. Consiste en encontrar parejas en 
un tablero de 12 cartas, que contiene 6 cartas repetidas de los personajes 
de los Simpson. El juego consistirá en lo siguiente:
• La aplicación deberá tener una tabla con 3 filas y cuatro columnas de 
  un color. Además, habrá un cuadro de texto con el valor 0 pero no modificable 
  y un botón que permita reiniciar el juego.
• Cuando el usuario haga clic sobre una celda, se mostrará una imagen.
• Cuando el usuario haga clic sobre otra celda, se mostrará otra imagen.
• Si las dos imágenes son iguales, se mantendrán visibles y se añadirá 1 al cuadro de texto.
• Si las dos imágenes son diferentes, se ocultarán mostrando nuevamente el color inicial.
• Cuando se hayan completado las 6 parejas, se mostrará el mensaje: ¡¡GANASTE!!
• El botón de reiniciar el juego, cambia el orden de las cartas para volver a jugar. 
El siguiente método te puede ayudar, permite ordenar un array aleatoriamente:
array.sort(() => 0.5 - Math.random());
*/
document.addEventListener("DOMContentLoaded", () => {
    //Definimos el array de cartas para el juego
    let cartas = ["Simpson/HomerSimpson.png",
        "Simpson/MargeSimpson.png",
        "Simpson/BartSimpson.png",
        "Simpson/LisaSimpson.png",
        "Simpson/MaggieSimpson.png",
        "Simpson/AbrahamSimpson.png",
        "Simpson/HomerSimpson.png",
        "Simpson/MargeSimpson.png",
        "Simpson/BartSimpson.png",
        "Simpson/LisaSimpson.png",
        "Simpson/MaggieSimpson.png",
        "Simpson/AbrahamSimpson.png",
    ];
    //Definimos las variables que vamos a necesitar: 
    //- para almacenar las imágenes seleccionadas
    let imagen1 = "";
    let imagen2 = "";
    //- para almacenar las id de cada elemento HTML seleccionado
    let idImagen1 = "";
    let idImagen2 = "";
    //- para modificar el número de parejas encontradas
    let aciertos = document.getElementById("contador");

    //Cargamos el tablero de cartas
    iniciarJuego();
    //Reiniciamos el juego si hacen clic en el botón correspondiente
    document.getElementById("reiniciar").addEventListener("click", iniciarJuego);

    //Función para iniciar o reiniciar el juego, reordena el array de cartas y lo 
    //recorre para asociar los eventos a las cartas
    function iniciarJuego() {
        cartas.sort(() => 0.5 - Math.random());
        for (let i = 0; i < cartas.length; i++) {
            let carta = document.getElementById(i.toString());
            carta.addEventListener("click", girarCarta);
            carta.src = "Simpson/question.png";
        }
        //Al reiniciar el juego tenemos que resetear los aciertos y el mensaje ganador
        aciertos.value = 0;
        document.getElementById("mensaje").style.display = "none";
    }

    //Función manejadora del evento: asocia los id e imágenes correspondientes dependiendo
    //de si es el primer o segundo clic sobre el tablero de cartas
    function girarCarta(e) {
        let evento = e || window.event;
        if (imagen1 === "") { 
            idImagen1 = evento.target.id;
            imagen1 = cartas[parseInt(idImagen1)];
            document.getElementById(idImagen1).src = imagen1;
        } else {
            idImagen2 = evento.target.id
            imagen2 = cartas[parseInt(idImagen2)];
            document.getElementById(idImagen2).src = imagen2;
            comprobarJugada();
        }
    }

    //Función que comprueba si las dos cartas son iguales o no y realiza las acciones
    //necesarias en cada caso
    function comprobarJugada() {
        if (imagen1 === imagen2 && idImagen1 !== idImagen2) {
            aciertos.value++;
            if (parseInt(aciertos.value) === 6)
                document.getElementById("mensaje").style.display = "block";
            limpiarJugada();
        } else if (idImagen1 !== idImagen2) {
            setTimeout(() => {
                document.getElementById(idImagen1).src = "Simpson/question.png";
                document.getElementById(idImagen2).src = "Simpson/question.png";
                limpiarJugada();
            }, 200);
        }
    }

    //Función que vacía las variables que van almacenando las jugadas
    function limpiarJugada() {
        imagen1 = "";
        imagen2 = "";
        idImagen1 = "";
        idImagen2 = "";
    }
});
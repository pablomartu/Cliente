/*
Modifica el ejercicio u4e08_test para que el usuario pueda salir de la página y 
continuar en otro momento.
*/

//Preguntas del test
let preguntas = document.getElementsByTagName("h4");
//Respuestas correctas para comparar con la seleccionada
let respuestas = ["mouseover", "funcion", "w3c", "load", "target", "novalidate", "null", "x427x9", "docCookie", "sessionStorage"];
//Array booleano para comprobar que se han contestado las preguntas
let seleccionadas = [];
//Contador de aciertos
let correctas = 0;
//Array booleano para almacenar si han respondido bien o mal
let resultado = [];

document.addEventListener("DOMContentLoaded", () => {
    document.getElementById("enviar").addEventListener("click", comprobar);
    //WebStorage: asignamos un evento a cada opción
    let opciones = document.getElementsByTagName("input");
    for (let i = 0; i < opciones.length; i++) {
        let item = opciones[i];
        item.addEventListener("click", crearItem);

        //Consultamos localStorage para cargar los datos almacenados
        if (localStorage.getItem(item.name) === item.value)
            item.checked = true;
    }

});

//Función para comprobar si han respondido a todas preguntas,
// si hay respuesta, se comprueba si es correcta o no
function comprobar() {
    //Recorremos las preguntas
    for (let i = 0; i < preguntas.length; i++) {
        //En principio no hay respuesta seleccionada
        seleccionadas[i] = false;
        let opciones = document.getElementsByName((i + 1).toString());
        for (let j = 0; j < opciones.length; j++) { //Cada respuesta de una pregunta
            if (opciones[j].checked) { //Si esta seleccionada
                seleccionadas[i] = true;
                if (opciones[j].value === respuestas[i]) { //Si es la respuesta es correcta
                    resultado[i] = true;
                    correctas++;
                } else {
                    resultado[i] = false;
                }
            }
        }
        //Si no se ha marcado una respuesta se resalta la pregunta en rojo
        if (!seleccionadas[i]) {
            preguntas[i].style.color = "red"; //Cambiar el color de la pregunta
        } else {
            preguntas[i].style.color = "black"; //Cambiar el color de la pregunta
        }
    }
    mostrarResultado();
}

//Función para mostrar el resultado obtenido
function mostrarResultado() {
    document.getElementById("mensaje").style.display = "block";
    if (!seleccionadas.includes(false)) {  //Si se han contestado todas
        for (let i = 0; i < resultado.length; i++) { //Marcamos correctas e incorrectas
            if (resultado[i]) {
                preguntas[i].nextElementSibling.style.display = "block";
                preguntas[i].nextElementSibling.nextElementSibling.style.display = "none";
            } else {
                preguntas[i].nextElementSibling.style.display = "none";
                preguntas[i].nextElementSibling.nextElementSibling.style.display = "block";
            }
        }
        document.getElementById("mensaje").innerHTML = "Has acertado " + correctas + "/10";
        //Limpiamos los datos almacenados en localStorage y el número de aciertos
        localStorage.clear();
        correctas = 0;
    } else { //Si no se han contestado todas
        document.getElementById("mensaje").innerHTML = "No has respondido a todas las preguntas";
    }
}

//Manejador del evento: almacena en localStorage el par clave/valor 
//de la opción seleccionada (los extraemos name/value del input)
function crearItem(e) {
    localStorage.setItem(e.target.name, e.target.value);
}